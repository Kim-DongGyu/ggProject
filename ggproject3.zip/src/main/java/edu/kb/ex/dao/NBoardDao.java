package edu.kb.ex.dao;

import java.sql.Date;
import java.util.ArrayList;



import edu.kb.ex.dto.ContractDto;

public interface NBoardDao {
	
	
	

}
